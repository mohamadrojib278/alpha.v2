from kyt import *
import subprocess
import requests
import datetime as DT
import asyncio
import math
import time
import random
import os
import re
from telethon import events
from telethon.tl.custom import Button
from telethon.errors import AlreadyInConversationError
from telethon.tl.custom import Button

# =================================================================
# GLOBAL STATE & INISIALISASI DATABASE TRIAL (ANTI REBOOT)
# =================================================================
active_convs = {}
TRIAL_DB = "/etc/kyt/trial_db.txt"

# Pastikan folder dan file database trial tersedia
if not os.path.exists("/etc/kyt"):
    os.makedirs("/etc/kyt", exist_ok=True)
if not os.path.exists(TRIAL_DB):
    with open(TRIAL_DB, 'w') as f:
        pass

async def trial_monitor():
    """Fungsi latar belakang untuk mengecek trial setiap 30 detik"""
    while True:
        try:
            if os.path.exists(TRIAL_DB):
                with open(TRIAL_DB, "r") as f:
                    lines = f.readlines()
                
                new_lines = []
                current_time = int(time.time())
                
                for line in lines:
                    parts = line.strip().split("|")
                    if len(parts) >= 3:
                        user = parts[0].strip()
                        exp_time = parts[1].strip()
                        chat_id = parts[2].strip()
                        
                        if current_time >= int(exp_time):
                            # --- 1. HAPUS DARI LINUX SYSTEM ---
                            subprocess.run(f'userdel -f {user}', shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
                            
                            # --- 2. HAPUS DARI SECURITY LIMITS & FOLDER LIMIT IP ---
                            subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
                            subprocess.run(f'rm -f /etc/kyt/limit/ssh/ip/{user}', shell=True)
                            
                            # --- 3. HAPUS DARI FOLDER QUOTA ---
                            subprocess.run(f'rm -f /etc/ssh/{user}', shell=True)
                            
                            # --- 4. HAPUS DARI DATABASE PANEL (.ssh.db) ---
                            subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)
                            
                            # Kirim Notifikasi ke Admin
                            try:
                                msg_expired = f"<b>🗑️ INFO AUTO-DELETE (TRIAL)</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nAkun Trial SSH <code>{user}</code> telah melewati batas waktu dan <b>berhasil dihapus</b> otomatis secara permanen dari seluruh sistem."
                                await bot.send_message(
                                    int(chat_id), 
                                    msg_expired, 
                                    parse_mode='html',
                                    buttons=[[Button.inline("🔙 Kembali ke Menu", "ssh")]]
                                )
                            except:
                                pass
                        else:
                            # Belum habis, simpan kembali
                            new_lines.append(line)
                
                # Timpa file database dengan data user yang masih aktif saja
                with open(TRIAL_DB, "w") as f:
                    f.writelines(new_lines)
        except Exception as e:
            pass # Cegah crash jika ada error pada proses baca file
        
        # Jeda 30 detik sebelum pengecekan loop berikutnya
        await asyncio.sleep(30)


# =================================================================
# HELPER: CANCEL PROCESS & PAGINATION
# =================================================================
@bot.on(events.CallbackQuery(data=b'cancel_process'))
async def cancel_process_handler(event):
    chat = event.chat_id
    if chat in active_convs:
        active_convs[chat].cancel()
        del active_convs[chat]
    await event.edit("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

def get_ssh_data():
    possible_paths = [
        '/usr/bin/kyt/shell/bot/bot-member-ssh',
        '/usr/bin/kyt/shell/bot-member-ssh',
        'bot-member-ssh'
    ]
    cmd = None
    for path in possible_paths:
        if os.path.exists(path):
            cmd = path
            break
            
    if not cmd: return []

    try:
        subprocess.run(f"chmod +x {cmd}", shell=True)
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except:
        return []

def get_vip_details(user):
    limit_ip = "Unlimited"
    quota_info = "Unlimited"
    status_lock = "🟢 Active"
    try:
        path_limit = f"/etc/kyt/limit/ssh/ip/{user}"
        if os.path.exists(path_limit):
            with open(path_limit, 'r') as f:
                val = f.read().strip()
                if val and val != "0": limit_ip = f"{val} Device"
    except: pass
    try:
        path_quota = f"/etc/ssh/{user}"
        if os.path.exists(path_quota):
            with open(path_quota, 'r') as f:
                content = f.read().strip()
                if content.isdigit():
                    bytes_val = int(content)
                    if bytes_val > 0:
                        gb_val = bytes_val / 1073741824
                        quota_info = f"{gb_val:.2f} GB"
    except: pass
    return limit_ip, quota_info, status_lock

# =================================================================
# MENU START (INFO MASA AKTIF VPS)
# =================================================================
@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("⚡ OPEN DASHBOARD PANEL","menu")],
        [Button.url("🛒 ORDER SCRIPT","https://t.me/HookageLegend"),
         Button.url("💬 OFFICIAL CHANNEL","https://t.me/hokagelegend1")]
    ]
    sender = await event.get_sender()
    chat_id = str(sender.id)
    first_name = sender.first_name
    
    val = valid(chat_id)
    if val == "false":
        try: await event.answer("❌ Akses Ditolak", alert=True)
        except: await event.reply("❌ Akses Ditolak")
    elif val == "true":
        sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii")

        status_user = "👑 ADMIN 👑"
        db_reseller = "/root/reseller_data.txt"
        try:
            if os.path.exists(db_reseller):
                with open(db_reseller, "r") as f:
                    data_lines = f.readlines()
                    for line in data_lines:
                        parts = line.strip().split("|")
                        if len(parts) >= 1:
                            if parts[0] == chat_id:
                                status_user = "💼 RESELLER PARTNER"
                                break
        except: pass

        # Cek Expired IP dari Github
        sisa_hari = "Unknown"
        try:
            url_izin = "https://raw.githubusercontent.com/hokagelegend9999/ijin/refs/heads/main/alpha"
            r = requests.get(url_izin)
            data = r.text
            my_ip = ipsaya.strip()
            for line in data.splitlines():
                if my_ip in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        exp_date = parts[2]
                        exp_dt = DT.datetime.strptime(exp_date, "%Y-%m-%d").date()
                        today = DT.date.today()
                        diff = (exp_dt - today).days
                        if diff >= 0: sisa_hari = f"{diff} Hari"
                        else: sisa_hari = "Expired"
                        break
        except Exception:
            sisa_hari = "Error Fetching"

        msg = f"""
<b>🌋 HOKAGE LEGEND STORE 🌋</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
👋 <b>Halo, {first_name}!</b>
<i>Selamat datang di Premium Management Panel.</i>
<b>👤 USER INFORMATION</b>
┌──────────────────────
│ <b>🆔 Telegram ID</b> : <code>{chat_id}</code>
│ <b>🏷️ Access Role</b> : <code>{status_user}</code>
└──────────────────────
<b>💻 SERVER INFORMATION</b>
┌──────────────────────
│ <b>⚙️ OS System</b>   : <code>{namaos.strip().replace('"','')}</code>
│ <b>📍 Location</b>    : <code>{city.strip()}</code>
│ <b>📡 Public IP</b>   : <code>{ipsaya.strip()}</code>
│ <b>🌐 Domain</b>      : <code>{DOMAIN}</code>
│ <b>⏳ Active Days</b> : <code>{sisa_hari}</code>
└──────────────────────
"""
        x = await event.edit(msg, buttons=inline, parse_mode='html')
        if not x: await event.reply(msg, buttons=inline, parse_mode='html')

# =================================================================
# MENU UTAMA (DASHBOARD)
# =================================================================
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id
    first_name = sender.first_name
    username = f"@{sender.username}" if sender.username else "No Username"
    val = valid(str(user_id))
    
    if val == "false":
        msg_denied = f"<b>⚠️ AKSES DITOLAK</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nMaaf <b>{first_name}</b>, ID Anda <code>{user_id}</code> Tidak terdaftar."
        try: await event.answer("Akses Ditolak!", alert=True)
        except: await event.reply(msg_denied, parse_mode='html')
    elif val == "true":
        if isinstance(event, events.CallbackQuery.Event):
            await event.answer("Memuat Dashboard...", alert=False)

        try:
            ssh = subprocess.check_output("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l", shell=True).decode("ascii").strip()
            vms = subprocess.check_output('vmc=$(grep -c -E "^### " "/etc/xray/config.json"); echo $((vmc / 2))', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('vlx=$(grep -c -E "^#& " "/etc/xray/config.json"); echo $((vlx / 2))', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('trx=$(grep -c -E "^#! " "/etc/xray/config.json"); echo $((trx / 2))', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g' | sed 's/\"//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            city = subprocess.check_output("cat /root/.info/.city 2>/dev/null || echo 'Server'", shell=True).decode("ascii").strip()
            
            # CEK EXPIRED IP DARI GITHUB UNTUK MENU
            url_izin = "https://raw.githubusercontent.com/hokagelegend9999/ijin/refs/heads/main/alpha"
            exp_date_vps = "-"
            try:
                r = requests.get(url_izin)
                for line in r.text.splitlines():
                    if ipsaya in line:
                        parts = line.split()
                        if len(parts) >= 3:
                            exp_date_vps = parts[2]
                        break
            except Exception:
                exp_date_vps = "Error Fetching"
        except Exception:
            ssh = vms = vls = trj = "0"
            namaos, ipsaya, city, exp_date_vps = "Ubuntu Linux", "127.0.0.1", "Unknown", "-"

        msg = f"""
<b>👑 PREMIUM CONTROL PANEL</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 USER INFORMATION</b>
🆔 <b>ID :</b> <code>{user_id}</code>
👻 <b>User :</b> {username}
👋 <b>Name :</b> {first_name}
📅 <b>Exp VPS :</b> <code>{exp_date_vps}</code>

<b>💻 SERVER INFORMATION</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🖥 <b>OS :</b> <code>{namaos}</code>
📍 <b>Loc :</b> <code>{city}</code>
📡 <b>IP :</b> <code>{ipsaya}</code>
🌐 <b>Domain :</b> <code>{DOMAIN}</code>

<b>📊 TUNNEL STATUS</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
☁️ <b>SSH OVPN :</b> <code>{ssh}</code> Accounts
⚡ <b>VMESS GW :</b> <code>{vms}</code> Accounts
🚀 <b>VLESS GW :</b> <code>{vls}</code> Accounts
🛡 <b>TROJAN GW :</b> <code>{trj}</code> Accounts
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Silakan pilih menu manajemen di bawah:</i>
"""
        inline = [
            [Button.inline("☁️ SSH OVPN", data="ssh"), Button.inline("⚡ VMESS", data="vmess")],
            [Button.inline("🚀 VLESS", data="vless"), Button.inline("🛡 TROJAN", data="trojan")],
            [Button.inline("👻 SHADOWSOCKS", data="shadowsocks"), Button.inline("⚙️ SETTINGS", data="setting")],
            [Button.inline("🖥 SERVICE STATUS", data="info"), Button.inline("📝 REGIS IP", data="regis")],
            [Button.inline("🔄 REFRESH DATA", data="menu")],
            [Button.inline("🔙 BACK TO START", data="start")] 
        ]
        try: await event.edit(msg, buttons=inline, parse_mode='html')
        except Exception: await event.reply(msg, buttons=inline, parse_mode='html')

# =================================================================
# MENU REGIS IP
# =================================================================
@bot.on(events.CallbackQuery(data=b'regis'))
async def regis_ip_check(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    try: msg_wait = await event.edit("<b>🔄 Checking IP License...</b>", parse_mode='html')
    except: msg_wait = await event.respond("<b>🔄 Checking IP License...</b>", parse_mode='html')

    try:
        my_ip = subprocess.check_output("curl -sS ipv4.icanhazip.com", shell=True).decode("utf-8").strip()
    except:
        my_ip = "Unknown IP"

    url_izin = "https://raw.githubusercontent.com/hokagelegend9999/ijin/refs/heads/main/alpha"
    try:
        r = requests.get(url_izin)
        data = r.text
    except:
        return await msg_wait.edit("❌ <b>Error:</b> Gagal menghubungi GitHub.", parse_mode='html')

    username, exp_date, status, validity = "Unregistered", "-", "🔴 Expired / Unregistered", "0 Days"
    found = False
    
    for line in data.splitlines():
        if my_ip in line:
            parts = line.split()
            if len(parts) >= 3:
                username, exp_date, found = parts[1], parts[2], True
                break
    
    if found:
        try:
            today = DT.date.today()
            exp_dt = DT.datetime.strptime(exp_date, "%Y-%m-%d").date()
            diff = (exp_dt - today).days
            validity = f"{diff} Days"
            if diff >= 0: status = "🟢 Active"
            else: status, validity = "🔴 Expired", "Expired"
        except: validity = "Error Date"
    
    msg = f"""
<b>📂 USER LICENSE STATUS</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🖥️ IP VPS      :</b> <code>{my_ip}</code>
<b>👤 Username    :</b> <code>{username}</code>
<b>📅 Expired     :</b> <code>{exp_date}</code>
<b>⏳ Validity    :</b> <code>{validity}</code>
<b>💎 Status      :</b> {status}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
    await msg_wait.edit(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]], parse_mode='html')


# =================================================================
# MENU SSH & VPN (CREATE, DELETE, TRIAL, SHOW, LOGIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    try:
        inline = [
            [Button.inline("☁️ TRIAL SSH ","trial-ssh"), Button.inline("⚡ CREATE SSH ","create-ssh")],
            [Button.inline("🗑️ DELETE SSH ","delete-ssh"), Button.inline("🔐 CHECK LOGIN","login-ssh")],
            [Button.inline("📊 LIST USER SSH ","show-ssh")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
             isp = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()
             country = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('country', 'Unknown'))\"", shell=True).decode("utf-8").strip()
        except:
             isp, country = "Unknown", "Unknown"

        msg = f"""
<b>☁️ SSH MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{DOMAIN}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
<b>🌍 Region/City    :</b> <code>{country}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error: {str(e)}")

# [ CREATE SSH ]
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)

    async def create_ssh_process():
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            async with bot.conversation(chat, timeout=120) as conv:
                active_convs[chat] = conv
                
                prompt_msg = await event.respond('<b>👤 Input Username:</b>', parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                user = ev.raw_text
                await prompt_msg.delete()
                
                prompt_msg = await event.respond("<b>🔑 Input Password:</b>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                pw = ev.raw_text
                await prompt_msg.delete()

                prompt_msg = await event.respond("<b>📱 Input Max Login/IP Limit:</b>\nContoh: <code>2</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                limit = ev.raw_text
                await prompt_msg.delete()

                prompt_msg = await event.respond("<b>💾 Input Quota (GB):</b>\nContoh: <code>10</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                quota = ev.raw_text
                await prompt_msg.delete()
            
                prompt_msg = await event.respond("<b>📅 Input Masa Aktif (Hari):</b>\nContoh: <code>30</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                exp = ev.raw_text
                await prompt_msg.delete()
        
            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>🔄 Processing SSH Account...</code>", parse_mode='html')
            
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            expe = later.strftime("%d %b, %Y")
            try: quota_bytes = int(quota.strip()) * 1024 * 1024 * 1024
            except: quota_bytes = 0

            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            cmd_sys += f' && mkdir -p /etc/kyt/limit/ssh/ip && echo "{limit.strip()}" > /etc/kyt/limit/ssh/ip/{user}'
            cmd_sys += f' && mkdir -p /etc/ssh && echo "{quota_bytes}" > /etc/ssh/{user}'
            cmd_sys += f' && sed -i "/\\b{user}\\b/d" /etc/ssh/.ssh.db'
            cmd_sys += f' && echo "#ssh# {user} {pw} {quota.strip()} {limit.strip()} {expe}" >> /etc/ssh/.ssh.db'
            
            try: subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError:
                await msg_load.delete()
                return await event.respond("<b>⚠️ User Already Exist / Error</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
            
            # Eksekusi berhasil, ambil informasi server tambahan
            try: ip_vps = requests.get("https://ipv4.icanhazip.com", timeout=3).text.strip()
            except: ip_vps = "Unknown"
            try:
                with open("/root/.info/.isp", "r") as f: isp_vps = f.read().strip()
            except: isp_vps = "Unknown"
            try:
                with open("/root/.info/.city", "r") as f: city_vps = f.read().strip()
            except: city_vps = "Unknown"
            try:
                with open("/etc/xray/dns", "r") as f: ns_vps = f.read().strip()
            except: ns_vps = "Not Set"
            try:
                with open("/etc/slowdns/server.pub", "r") as f: pub_vps = f.read().strip()
            except: pub_vps = "Not Set"
            udp_zivpn = "5667"
            try:
                with open("/etc/zivpn/config.json", "r") as f:
                    for line in f:
                        if '"listen"' in line:
                            udp_zivpn = line.split('"')[3].replace(':', '').replace('0.0.0.0', '')
                            break
            except: pass

            msg = f"""
<b>🌟 PREMIUM ACCOUNT SSH 🌟</b>
━━━━━━━━━━━━━━━━━━━━━━
<b>👤 ACCOUNT INFO</b>
┌ <b>🌐 Domain :</b> <code>{DOMAIN}</code>
├ <b>👻 User   :</b> <code>{user.strip()}</code>
├ <b>🔑 Pass   :</b> <code>{pw.strip()}</code>
├ <b>📱 Limit  :</b> <code>{limit.strip()} Device</code>
└ <b>💾 Quota  :</b> <code>{quota.strip()} GB</code>

<b>💻 SERVER INFO</b>
┌ <b>📡 IP     :</b> <code>{ip_vps}</code>
├ <b>🏢 ISP    :</b> <code>{isp_vps}</code>
├ <b>📍 Loc    :</b> <code>{city_vps}</code>
└ <b>☁️ HostNS :</b> <code>{ns_vps}</code>

<b>🔌 PORT INFORMATION</b>
┌ <b>Dropbear :</b> <code>443, 109</code>
├ <b>OpenSSH  :</b> <code>443, 80, 22</code>
├ <b>SSH WS   :</b> <code>80, 8080, 8880, 2082</code>
├ <b>SSH UDP  :</b> <code>1-65535</code>
├ <b>OVPN SSL :</b> <code>443</code>
├ <b>OVPN TCP :</b> <code>443, 1194</code>
├ <b>OVPN UDP :</b> <code>2200</code>
├ <b>BadVPN   :</b> <code>7100, 7300, 7300</code>
├ <b>Port DNS :</b> <code>443, 53, 22</code>
└ <b>Pub Key  :</b> <code>{pub_vps}</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>🛠️ PAYLOAD WEBSOCKET</b>
<code>GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>🔒 PAYLOAD SSL/TLS</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>📥 DOWNLOAD OVPN</b>
<code>https://{DOMAIN}:81/</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>⏳ Expired :</b> <code>{expe}</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>» 👤 Admin : @HookageLegend</b>
"""
            await msg_load.delete()
            await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali ke Menu", "ssh")]])

        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Sedang ada proses lain! Selesaikan atau batalkan dulu.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis.</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error:</b> <code>{str(e)}</code>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')

    await create_ssh_process()

# [ TRIAL SSH WITH IP & QUOTA LIMIT + AUTO-DELETE ]
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)

    async def trial_ssh_process():
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            async with bot.conversation(chat, timeout=120) as conv:
                active_convs[chat] = conv
                
                # 1. Input Waktu
                prompt_msg = await event.respond("<b>⏱️ Input Trial Time (Menit):</b>\nContoh: <code>10</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.delete()
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                exp_minutes = ev.raw_text
                await prompt_msg.delete()
                
                if not exp_minutes.isdigit():
                     active_convs.pop(chat, None)
                     return await event.respond("<b>❌ Error: Harap masukkan angka untuk menit.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

                # 2. Input Limit IP
                prompt_msg = await event.respond("<b>📱 Input Max Login/IP Limit:</b>\nContoh: <code>1</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.delete()
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                limit = ev.raw_text
                await prompt_msg.delete()

                # 3. Input Kuota
                prompt_msg = await event.respond("<b>💾 Input Quota (GB):</b>\nContoh: <code>2</code>\n<i>(Ketik 0 jika ingin unlimited trial)</i>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.delete()
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                quota = ev.raw_text
                await prompt_msg.delete()

            active_convs.pop(chat, None)
            
            user = "trialX"+str(random.randint(100,1000))
            pw = "1"
            
            # Hitung Kuota ke Bytes
            try: quota_bytes = int(quota.strip()) * 1024 * 1024 * 1024
            except: quota_bytes = 0
            
            msg_load = await event.respond("<code>🔄 Creating Trial SSH...</code>", parse_mode='html')
            
            # Hitung Tanggal untuk disimpan di DB SSH (agar rapi bila dicek)
            now = DT.datetime.now()
            end_time = now + DT.timedelta(minutes=int(exp_minutes))
            end_time_str = end_time.strftime("%d %b %Y, %H:%M:%S")
            expe_db = end_time.strftime("%d %b, %Y")
            
            # Eksekusi Pembuatan & Penulisan Database Limit
            cmd_sys = f'useradd -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            cmd_sys += f' && mkdir -p /etc/kyt/limit/ssh/ip && echo "{limit.strip()}" > /etc/kyt/limit/ssh/ip/{user}'
            cmd_sys += f' && mkdir -p /etc/ssh && echo "{quota_bytes}" > /etc/ssh/{user}'
            cmd_sys += f' && sed -i "/\\b{user}\\b/d" /etc/ssh/.ssh.db'
            cmd_sys += f' && echo "#ssh# {user} {pw} {quota.strip()} {limit.strip()} {expe_db}" >> /etc/ssh/.ssh.db'
            
            try: subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError:
                await msg_load.delete()
                return await event.respond("<b>❌ Failed to create trial.</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
            
            # Ambil Informasi Server
            try: ip_vps = requests.get("https://ipv4.icanhazip.com", timeout=3).text.strip()
            except: ip_vps = "Unknown"
            try:
                with open("/root/.info/.isp", "r") as f: isp_vps = f.read().strip()
            except: isp_vps = "Unknown"
            try:
                with open("/root/.info/.city", "r") as f: city_vps = f.read().strip()
            except: city_vps = "Unknown"
            try:
                with open("/etc/xray/dns", "r") as f: ns_vps = f.read().strip()
            except: ns_vps = "Not Set"
            try:
                with open("/etc/slowdns/server.pub", "r") as f: pub_vps = f.read().strip()
            except: pub_vps = "Not Set"

            msg = f"""
<b>🌟 PREMIUM TRIAL SSH 🌟</b>
━━━━━━━━━━━━━━━━━━━━━━
<b>👤 ACCOUNT INFO</b>
┌ <b>🌐 Domain :</b> <code>{DOMAIN}</code>
├ <b>👻 User   :</b> <code>{user.strip()}</code>
├ <b>🔑 Pass   :</b> <code>{pw.strip()}</code>
├ <b>📱 Limit  :</b> <code>{limit.strip()} Device</code>
└ <b>💾 Quota  :</b> <code>{quota.strip()} GB</code>

<b>💻 SERVER INFO</b>
┌ <b>📡 IP     :</b> <code>{ip_vps}</code>
├ <b>🏢 ISP    :</b> <code>{isp_vps}</code>
├ <b>📍 Loc    :</b> <code>{city_vps}</code>
└ <b>☁️ HostNS :</b> <code>{ns_vps}</code>

<b>🔌 PORT INFORMATION</b>
┌ <b>Dropbear :</b> <code>443, 109</code>
├ <b>OpenSSH  :</b> <code>443, 80, 22</code>
├ <b>SSH WS   :</b> <code>80, 8080, 8880, 2082</code>
├ <b>SSH UDP  :</b> <code>1-65535</code>
├ <b>OVPN SSL :</b> <code>443</code>
├ <b>OVPN TCP :</b> <code>443, 1194</code>
├ <b>OVPN UDP :</b> <code>2200</code>
├ <b>BadVPN   :</b> <code>7100, 7300, 7300</code>
├ <b>Port DNS :</b> <code>443, 53, 22</code>
└ <b>Pub Key  :</b> <code>{pub_vps}</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>🛠️ PAYLOAD WEBSOCKET</b>
<code>GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>🔒 PAYLOAD SSL/TLS</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>📥 DOWNLOAD OVPN</b>
<code>https://{DOMAIN}:81/</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>⏳ Expired :</b> <code>{end_time_str}</code> (Aktif {exp_minutes} Menit)
<i>⚠️ Akun akan terhapus otomatis setelah batas waktu habis.</i>
━━━━━━━━━━━━━━━━━━━━━━
<b>» 👤 Admin : @HookageLegend</b>
"""
            await msg_load.delete()
            await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali ke Menu", "ssh")]])

            # ---> SIMPAN KE DATABASE LOKAL AGAR KEBAL REBOOT <---
            exp_timestamp = int(time.time()) + (int(exp_minutes) * 60)
            with open(TRIAL_DB, "a") as f:
                f.write(f"{user}|{exp_timestamp}|{chat}\n")
        
        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Sedang ada proses lain! Selesaikan atau batalkan dulu.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis.</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error:</b> <code>{str(e)}</code>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
            
    await trial_ssh_process()

# [ DELETE SSH MENU ]
async def render_delete_menu(event, page):
    data_list = get_ssh_data() 
    item_per_page = 5
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0

    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]

    msg = f"<b>🗑️ DELETE SSH ACCOUNT</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    buttons = []
    number_buttons = []
    
    if not sliced_data: msg += "<i>⚠️ Tidak ada user terdaftar.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            try:
                parts = row.split("|")
                if len(parts) >= 1:
                    user = parts[0].strip()
                    try:
                        cmd_exp = f"chage -l {user} | grep 'Account expires' | cut -d: -f2"
                        exp_raw = subprocess.check_output(cmd_exp, shell=True).decode("utf-8").strip()
                        exp_date = "Unlimited" if "never" in exp_raw else exp_raw
                    except: exp_date = parts[1].strip() if len(parts) > 1 else "Unknown"

                    limit, quota, status = get_vip_details(user)
                    nomor = start + i + 1 
                    
                    msg += f"""<b>{nomor}. {user}</b> | {status}
   ├ 📅 Exp: <code>{exp_date}</code>
   ├ 💾 Quota: <code>{quota}</code>
   └ 📱 Limit: <code>{limit}</code>
"""
                    number_buttons.append(Button.inline(f"❌ {nomor}", data=f"del_cf:{user}"))
            except: continue

    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page + 1}/{total_pages}"
    
    if number_buttons: buttons.append(number_buttons)
        
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"del_pg:{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"del_pg:{page+1}"))
    
    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("🔙 Kembali", "ssh")])

    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.respond(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh_menu(event):
    if valid(str(event.sender_id)) != "true": return await event.answer("Akses Ditolak", alert=True)
    await render_delete_menu(event, 0)

@bot.on(events.CallbackQuery(pattern=b'del_pg:(\d+)'))
async def delete_ssh_paginate(event):
    if valid(str(event.sender_id)) != "true": return
    try: await render_delete_menu(event, int(event.data.decode().split(':')[1]))
    except: await event.answer("Error Pagination")

@bot.on(events.CallbackQuery(pattern=b'del_cf:(.*)'))
async def delete_ssh_confirm(event):
    if valid(str(event.sender_id)) != "true": return
    user_to_del = event.data.decode().split(':')[1]
    msg = f"<b>❓ KONFIRMASI PENGHAPUSAN</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nApakah Anda yakin ingin menghapus user ini?\n\n👤 <b>User :</b> <code>{user_to_del}</code>\n\n<i>⚠️ Data user, limit, dan quota akan dihapus permanen!</i>"
    buttons = [[Button.inline("✅ YA, HAPUS PERMANEN", data=f"del_ex:{user_to_del}")],[Button.inline("🔙 BATAL", data="delete-ssh")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'del_ex:(.*)'))
async def delete_ssh_execute(event):
    if valid(str(event.sender_id)) != "true": return
    user = event.data.decode().split(':')[1]
    msg_load = await event.edit("<b>🔄 Processing Deletion...</b>", parse_mode='html')
    try:
        try: subprocess.check_output(f'userdel -f {user}', shell=True, stderr=subprocess.STDOUT)
        except: pass 
        subprocess.run(f'rm -f /etc/kyt/limit/ssh/ip/{user}', shell=True)
        subprocess.run(f'rm -f /etc/ssh/{user}', shell=True)
        subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
        subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)
        
        # Remove from trial db if exists
        try:
            with open(TRIAL_DB, "r") as f: lines = f.readlines()
            with open(TRIAL_DB, "w") as f:
                for line in lines:
                    if not line.startswith(f"{user}|"): f.write(line)
        except: pass

        await msg_load.edit(f"<b>✅ DELETED SUCCESSFULLY</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👤 User <code>{user}</code> telah berhasil dihapus beserta seluruh datanya.", buttons=[[Button.inline("🔙 Kembali ke Menu List", "delete-ssh")]], parse_mode='html')
    except Exception as e: await msg_load.edit(f"<b>❌ Error:</b> {str(e)}", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')


def get_full_user_detail(username):
    domain = DOMAIN if 'DOMAIN' in globals() else "IP-Only"
    try:
        with open("/etc/xray/domain", "r") as f: domain = f.read().strip()
    except: pass
    
    ip = "Unknown"
    try: ip = requests.get("https://ipv4.icanhazip.com", timeout=3).text.strip()
    except: pass
    
    pub, ns, isp, city = "Not Set", "Not Set", "Unknown", "Unknown"
    try:
        with open("/etc/slowdns/server.pub", "r") as f: pub = f.read().strip()
    except: pass
    try:
        with open("/etc/xray/dns", "r") as f: ns = f.read().strip()
    except: pass
    try:
        with open("/root/.info/.isp", "r") as f: isp = f.read().strip()
    except: pass
    try:
        with open("/root/.info/.city", "r") as f: city = f.read().strip()
    except: pass

    password, quota, iplimit = "???", "0", "0"
    exp_date_fmt = "Unknown"
    
    # 1. Ambil data dasar dari .ssh.db
    try:
        with open("/etc/ssh/.ssh.db", "r") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 5 and parts[0] == "#ssh#" and parts[1] == username:
                    password, quota, iplimit = parts[2], parts[3], parts[4]
                    if len(parts) >= 8: exp_date_fmt = f"{parts[5]} {parts[6]} {parts[7]}"
                    break
    except: pass

    is_trial = False
    trial_msg_addon = ""
    
    # 2. Cek apakah ini Akun Trial dari database trial
    try:
        if os.path.exists("/etc/kyt/trial_db.txt"):
            with open("/etc/kyt/trial_db.txt", "r") as f:
                for line in f:
                    parts = line.strip().split("|")
                    if len(parts) == 3 and parts[0] == username:
                        is_trial = True
                        exp_timestamp = int(parts[1])
                        exp_dt = DT.datetime.fromtimestamp(exp_timestamp)
                        
                        # Hitung sisa menit secara live
                        sisa_menit = (exp_timestamp - int(time.time())) // 60
                        if sisa_menit < 0: sisa_menit = 0
                        
                        exp_date_fmt = exp_dt.strftime("%d %b %Y, %H:%M:%S") + f" (Sisa {sisa_menit} Menit)"
                        trial_msg_addon = "\n<i>⚠️ Akun akan terhapus otomatis setelah batas waktu habis.</i>"
                        break
    except: pass

    # 3. Jika BUKAN trial, cek masa aktif permanen (dari chage)
    if not is_trial:
        try:
            exp_raw = subprocess.check_output(f"chage -l {username} | grep 'Account expires' | cut -d: -f2", shell=True).decode("utf-8").strip()
            # Hindari kata "never" merusak tampilan
            if "never" not in exp_raw.lower() and exp_raw:
                dt = DT.datetime.strptime(exp_raw, "%b %d, %Y")
                exp_date_fmt = dt.strftime("%d %b, %Y")
            elif "never" in exp_raw.lower() and exp_date_fmt == "Unknown":
                exp_date_fmt = "Unlimited"
        except: pass

    # 4. Ganti Judul Secara Dinamis
    title_header = "🌟 DETAIL TRIAL SSH 🌟" if is_trial else "🌟 PREMIUM ACCOUNT SSH 🌟"

    msg = f"""
<b>{title_header}</b>
━━━━━━━━━━━━━━━━━━━━━━
<b>👤 ACCOUNT INFO</b>
┌ <b>🌐 Domain :</b> <code>{domain}</code>
├ <b>👻 User   :</b> <code>{username}</code>
├ <b>🔑 Pass   :</b> <code>{password}</code>
├ <b>📱 Limit  :</b> <code>{iplimit} Device</code>
└ <b>💾 Quota  :</b> <code>{quota} GB</code>

<b>💻 SERVER INFO</b>
┌ <b>📡 IP     :</b> <code>{ip}</code>
├ <b>🏢 ISP    :</b> <code>{isp}</code>
├ <b>📍 Loc    :</b> <code>{city}</code>
└ <b>☁️ HostNS :</b> <code>{ns}</code>

<b>🔌 PORT INFORMATION</b>
┌ <b>Dropbear :</b> <code>443, 109</code>
├ <b>OpenSSH  :</b> <code>443, 80, 22</code>
├ <b>SSH WS   :</b> <code>80, 8080, 8880, 2082</code>
├ <b>SSH UDP  :</b> <code>1-65535</code>
├ <b>OVPN SSL :</b> <code>443</code>
├ <b>OVPN TCP :</b> <code>443, 1194</code>
├ <b>OVPN UDP :</b> <code>2200</code>
├ <b>BadVPN   :</b> <code>7100, 7300, 7300</code>
├ <b>Port DNS :</b> <code>443, 53, 22</code>
└ <b>Pub Key  :</b> <code>{pub}</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>🛠️ PAYLOAD WEBSOCKET</b>
<code>GET / HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>🔒 PAYLOAD SSL/TLS</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>📥 DOWNLOAD OVPN</b>
<code>https://{domain}:81/</code>
━━━━━━━━━━━━━━━━━━━━━━
<b>⏳ Expired :</b> <code>{exp_date_fmt}</code>{trial_msg_addon}
━━━━━━━━━━━━━━━━━━━━━━
<b>» 👤 Admin : @HookageLegend</b>
"""
    return msg

async def render_show_menu(event, page):
    data_list = get_ssh_data()
    item_per_page = 5  
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0

    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]

    msg = f"<b>☁️ LIST MEMBER SSH & VPN</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    buttons = []
    number_buttons = []

    if not sliced_data: msg += "<i>⚠️ Tidak ada user terdaftar.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            try:
                parts = row.split("|")
                if len(parts) >= 1:
                    user = parts[0].strip()
                    exp_date = parts[1].strip() if len(parts) > 1 else "Unknown"
                    status = parts[2].strip() if len(parts) > 2 else "UNKNOWN"
                    icon_stat = "🟢" if "UNLOCKED" in status.upper() else "🔴"
                    nomor = start + i + 1

                    msg += f"<b>{nomor}. User:</b> <code>{user}</code>\n"
                    msg += f"   ├ 📅 Exp: <code>{exp_date}</code>\n"
                    msg += f"   └ 💎 Stat: {icon_stat} <code>{status}</code>\n\n"
                    number_buttons.append(Button.inline(str(nomor), data=f"detail_cf:{user}"))
            except: continue

    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page + 1}/{total_pages}"
    if number_buttons: buttons.append(number_buttons)

    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"show_pg:{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"show_pg:{page+1}"))
    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("🔙 Kembali", "ssh")])

    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.respond(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh_menu(event):
    if valid(str(event.sender_id)) != "true": return await event.answer("Akses Ditolak", alert=True)
    await render_show_menu(event, 0)

@bot.on(events.CallbackQuery(pattern=b'show_pg:(\d+)'))
async def show_ssh_paginate(event):
    if valid(str(event.sender_id)) != "true": return
    try: await render_show_menu(event, int(event.data.decode().split(':')[1]))
    except: await event.answer("Error Pagination")

@bot.on(events.CallbackQuery(pattern=b'detail_cf:(.*)'))
async def detail_ssh_confirm(event):
    if valid(str(event.sender_id)) != "true": return
    user = event.data.decode().split(':')[1]
    msg_load = await event.edit("<b>🔄 Mengambil Detail Data...</b>", parse_mode='html')
    try:
        detail_msg = get_full_user_detail(user)
        await msg_load.edit(detail_msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali ke List", "show-ssh")]])
    except Exception as e:
        await msg_load.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "show-ssh")]])


# [ TRAFFIC MONITOR SSH / LOGIN SSH ]
def parse_monitor_data(text):
    user_data = []
    current_user = {}
    
    clean_text = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', text)
    clean_text = re.sub(r'\[\d+(?:;\d+)*[a-zA-Z]', '', clean_text)
    clean_text = re.sub(r'[│┌└├╭╰╮╯╔╚║╠╣─═┐┤┘╗╝╖╜╢╟><]', '', clean_text)
    clean_text = clean_text.replace('\r', '\n')
    clean_text = re.sub(r' +', ' ', clean_text)
    
    if "DAFTAR USER ONLINE" in clean_text.upper():
        clean_text = re.split(r'(?i)DAFTAR USER ONLINE', clean_text)[-1]
        
    for line in clean_text.splitlines():
        line = line.strip()
        if not line: continue
        if ":" in line:
            parts = line.split(":", 1)
            raw_key = parts[0].strip().lower()
            key = re.sub(r'[^a-z ]', '', raw_key).strip()
            val = parts[1].strip()
            
            std_key = None
            if key in ["user", "username", "akun"]: std_key = "user"
            elif key in ["pass", "password"]: std_key = "pw"
            elif key in ["expired", "exp"]: std_key = "exp"
            elif key in ["usage", "data usage"]: std_key = "usage"
            elif key in ["status"]: std_key = "status"
            elif key in ["tipe vpn", "tipe"]: std_key = "tipe"
            elif key in ["ip address", "ip"]: std_key = "ip"
            elif key in ["proses lgn", "login", "jml login", "port masuk"]: 
                if key != "port masuk": std_key = "login"
            
            if not std_key: continue
            if std_key in current_user:
                user_data.append(current_user)
                current_user = {}
                
            if std_key == "login":
                match = re.search(r'^(\d+)', val)
                current_user["login"] = match.group(1) if match else val
            else:
                current_user[std_key] = val

    if current_user: user_data.append(current_user)
    return user_data

def render_monitor_page(user_data, page, item_per_page=5):
    total_items = len(user_data)
    total_pages = math.ceil(total_items / item_per_page)
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = user_data[start:end]
    
    msg = f"<b>☁️ TRAFFIC MONITOR SSH & VPN</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
    if not sliced_data: msg += "<i>⚠️ Tidak ada user online saat ini.</i>\n\n"
    else:
        for u in sliced_data:
            user = u.get('user', '-').strip()
            usage = u.get('usage', '0 B').strip()
            
            raw_st = u.get("status", "ACTIVE").strip()
            clean_st = re.sub(r'[🟢🔴]', '', raw_st).strip()
            clean_st = re.sub(r'(?i)(udp|zivpn|mode|/)', '', clean_st).strip()
            if not clean_st or len(clean_st) < 2: clean_st = "ONLINE"
                
            is_expired = "expired" in u.get('exp', '').lower()
            icon_st = "🔴" if is_expired else "🟢"
            
            msg += f"<b>👤 User :</b> <code>{user}</code>\n"
            if 'ip' in u: msg += f"<b>🌐 IP   :</b> <code>{u['ip']}</code>\n"
            if 'tipe' in u: msg += f"<b>🛡️ Tipe :</b> <code>{u['tipe']}</code>\n"
            if 'login' in u: msg += f"<b>📱 Login:</b> <code>{u['login']} Device</code>\n"
            if 'pw' in u: msg += f"<b>🔑 Pass :</b> <code>{u['pw']}</code>\n"
            if 'exp' in u: msg += f"<b>📅 Exp  :</b> <code>{u['exp']}</code>\n"
            msg += f"<b>📊 Usage:</b> <code>{usage}</code>\n"
            msg += f"<b>💎 Stat :</b> {icon_st} <code>{clean_st}</code>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            
    display_page = page + 1 if total_pages > 0 else 0
    msg += f"📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages, page

async def run_login_monitor(event, page=0):
    possible_paths = ['/usr/local/sbin/cekssh', '/usr/bin/kyt/shell/bot-login-monitor ', '/usr/bin/cekssh', 'cekssh']
    cmd = None
    for path in possible_paths:
        if os.path.exists(path):
            cmd = path
            break

    try: msg_wait = await event.edit("<b>🔄 Scanning Network...</b>\n<i>Mohon tunggu sebentar...</i>", parse_mode='html')
    except: msg_wait = await event.respond("<b>🔄 Scanning Network...</b>\n<i>Mohon tunggu sebentar...</i>", parse_mode='html')
    
    try:
        if not cmd: return await msg_wait.edit("❌ <b>Error:</b> Script bash monitor tidak ditemukan.", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
        process = subprocess.run(f"echo '' | {cmd}", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=20)
        raw_output = process.stdout.decode("utf-8", errors="ignore")
        user_list = parse_monitor_data(raw_output)
        
        if not user_list and len(raw_output) > 50: 
            if "ONLINE" in raw_output.upper() or "DAFTAR USER" in raw_output.upper() or "DATABASE MEMBER" in raw_output.upper() or "User" in raw_output:
                clean_raw = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]|\[\d+(?:;\d+)*[a-zA-Z]|[│┌└├╭╰╮╯╔╚║╠╣─═┐┤┘╗╝╖╜╢╟><]', '', raw_output).replace('\r', '\n')
                clean_raw = re.sub(r'\n\s*\n', '\n', clean_raw) 
                debug_msg = f"⚠️ <b>DATA MENTAH (DEBUG MODE)</b>\n\n<b>Monitor Traffic:</b>\n<pre>{clean_raw[:3500]}</pre>"
                return await msg_wait.edit(debug_msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

        if not raw_output.strip():
             return await msg_wait.edit("⚠️ <b>Script bash mengembalikan teks kosong!</b>\nCoba jalankan manual di VPS.", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

        final_msg, total_pages, current_page = render_monitor_page(user_list, page, item_per_page=5)
        nav_buttons = []
        if current_page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"loginPage_{current_page-1}"))
        if current_page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"loginPage_{current_page+1}"))
        
        buttons = []
        if nav_buttons: buttons.append(nav_buttons)
        buttons.append([Button.inline("🔄 Refresh (Live)", data=f"loginPage_{current_page}"), Button.inline("🔙 Kembali", "ssh")])
        await msg_wait.edit(final_msg, buttons=buttons, parse_mode='html')
        
    except subprocess.TimeoutExpired: await msg_wait.edit("<b>❌ Error:</b> Proses scanning terlalu lama (Timeout).", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
    except Exception as e: await msg_wait.edit(f"<b>❌ Error System:</b>\n<code>{str(e)}</code>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    if valid(str(event.sender_id)) != "true": return await event.answer("Access Denied", alert=True)
    await run_login_monitor(event, page=0)

@bot.on(events.CallbackQuery(pattern=b'loginPage_(\d+)'))
async def paginate_login(event):
    if valid(str(event.sender_id)) != "true": return
    try: page = int(event.data.decode().split('_')[1])
    except: page = 0
    await run_login_monitor(event, page=page)

# =================================================================
# PEMICU BACKGROUND TASK (HARUS ADA DI PALING BAWAH SCRIPT)
# =================================================================
try:
    bot.loop.create_task(trial_monitor())
except Exception as e:
    print(f"Gagal memulai task trial monitor: {e}")