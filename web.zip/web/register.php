<?php
$db_file = '/var/www/html/web_users.db';
$db = new PDO("sqlite:" . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// Buat tabel otomatis jika belum ada
$db->exec("CREATE TABLE IF NOT EXISTS web_users (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT UNIQUE, password TEXT)");

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tid = trim($_POST['telegram_id']);
    $pass = $_POST['password'];
    $hash = password_hash($pass, PASSWORD_DEFAULT); // Enkripsi password

    try {
        $stmt = $db->prepare("INSERT INTO web_users (telegram_id, password) VALUES (?, ?)");
        $stmt->execute([$tid, $hash]);
        $msg = "<div class='alert success'>✅ Registrasi berhasil! Silakan <a href='login.php' style='color:#fff; font-weight:bold;'>Login di sini</a>.</div>";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { 
            $msg = "<div class='alert error'>❌ Error: ID Telegram / Username sudah terdaftar!</div>";
        } else {
            $msg = "<div class='alert error'>❌ Error System: " . $e->getMessage() . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - J1BTNL STORE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        :root { 
            --primary-neon: #00e5ff; 
            --secondary-neon: #bd00ff;
            --bg-dark: #0a0a12;
        }

        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            font-family: 'Poppins', sans-serif; 
        }

        body { 
            background-color: var(--bg-dark);
            /* Background pattern/gradient modern */
            background-image: 
                radial-gradient(circle at 15% 50%, rgba(189, 0, 255, 0.15), transparent 25%),
                radial-gradient(circle at 85% 30%, rgba(0, 229, 255, 0.15), transparent 25%);
            color: #fff; 
            min-height: 100vh; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
        }

        .auth-box { 
            /* Efek Glassmorphism */
            background: rgba(20, 20, 30, 0.6); 
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(0, 229, 255, 0.2); 
            padding: 40px; 
            border-radius: 20px; 
            width: 90%; 
            max-width: 420px; 
            text-align: center; 
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5), 0 0 20px rgba(189, 0, 255, 0.1); 
        }

        .brand-logo {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
            background: linear-gradient(90deg, var(--primary-neon), var(--secondary-neon));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        p.desc { 
            color: #8b8b99; 
            font-size: 0.9rem; 
            margin-bottom: 30px; 
        }

        .form-group { 
            margin-bottom: 20px; 
            text-align: left; 
            position: relative;
        }

        .form-group label { 
            display: block; 
            margin-bottom: 8px; 
            color: #c8c8d0; 
            font-size: 0.85rem; 
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .form-control { 
            width: 100%; 
            padding: 14px 14px 14px 40px; 
            border-radius: 10px; 
            border: 1px solid rgba(255,255,255,0.1); 
            background: rgba(0,0,0,0.4); 
            color: #fff; 
            font-size: 0.95rem; 
            outline: none; 
            transition: all 0.3s ease;
        }

        .form-group i.icon-input {
            position: absolute;
            left: 14px;
            top: 38px;
            color: #8b8b99;
            transition: 0.3s ease;
        }

        .form-control:focus { 
            border-color: var(--primary-neon); 
            box-shadow: 0 0 10px rgba(0, 229, 255, 0.2);
            background: rgba(0,0,0,0.6);
        }

        .form-control:focus + i.icon-input {
            color: var(--primary-neon);
        }

        .btn { 
            display: inline-block; 
            background: linear-gradient(45deg, var(--secondary-neon), var(--primary-neon)); 
            color: #fff; 
            padding: 14px; 
            border-radius: 10px; 
            font-weight: 700; 
            width: 100%; 
            border: none; 
            cursor: pointer; 
            transition: all 0.3s ease; 
            margin-top: 15px; 
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn:hover { 
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 229, 255, 0.4); 
        }

        .links-container {
            margin-top: 25px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .link { 
            color: #8b8b99; 
            text-decoration: none; 
            font-size: 0.85rem; 
            transition: 0.3s; 
        }

        .link:hover { 
            color: var(--primary-neon); 
        }

        .alert { 
            padding: 12px; 
            border-radius: 8px; 
            margin-bottom: 20px; 
            font-size: 0.85rem; 
            display: flex;
            align-items: center;
            gap: 10px;
            text-align: left;
        }

        .alert.success { background: rgba(46, 204, 113, 0.1); border: 1px solid #2ecc71; color: #2ecc71; }
        .alert.error { background: rgba(231, 76, 60, 0.1); border: 1px solid #e74c3c; color: #e74c3c; }
    </style>
</head>
<body>
    <div class="auth-box">
        <div class="brand-logo">J1BTNL STORE</div>
        <p class="desc">Level up pengalaman transaksimu sekarang.</p>
        
        <!-- Pesan Alert -->
        <?= $msg ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>ID Telegram / Username</label>
                <i class="fas fa-user icon-input"></i>
                <input type="text" name="telegram_id" class="form-control" placeholder="Masukkan ID Telegram" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <i class="fas fa-lock icon-input"></i>
                <input type="password" name="password" class="form-control" placeholder="Buat Password" required minlength="4">
            </div>
            <button type="submit" class="btn">Daftar Akun <i class="fas fa-rocket"></i></button>
        </form>
        
        <div class="links-container">
            <a href="login.php" class="link">Sudah punya akun? <b>Login di sini</b>.</a>
            <a href="index.php" class="link"><i class="fas fa-arrow-left"></i> Kembali ke Beranda</a>
        </div>
    </div>
</body>
</html>