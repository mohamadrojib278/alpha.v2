<?php
session_start();

// ==========================================
// KONFIGURASI PASSWORD ADMIN (UBAH INI)
// ==========================================
$ADMIN_PASSWORD = "admin123"; 

// --- Proses Logout ---
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// --- Proses Login Admin ---
$login_err = "";
if (isset($_POST['login_admin'])) {
    if ($_POST['password'] === $ADMIN_PASSWORD) {
        $_SESSION['is_admin'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $login_err = "Password Admin Salah!";
    }
}

// --- Halaman Login (Jika belum login) ---
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8"><title>Admin Login - Hokage Legend</title>
        <style>
            body { background: #0f2027; color: #fff; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .box { background: rgba(255,255,255,0.1); padding: 40px; border-radius: 10px; text-align: center; border: 1px solid #f39c12; }
            input { padding: 10px; width: 100%; margin: 10px 0; border-radius: 5px; border: none; }
            button { padding: 10px; width: 100%; background: #f39c12; color: #111; font-weight: bold; border: none; cursor: pointer; border-radius: 5px;}
        </style>
    </head>
    <body>
        <div class="box">
            <h2 style="color: #f39c12;">👑 ADMIN PANEL</h2>
            <p style="color: #ff4757;"><?= $login_err ?></p>
            <form method="POST">
                <input type="password" name="password" placeholder="Masukkan Password Admin" required>
                <button type="submit" name="login_admin">Masuk Panel</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ==========================================
// KONEKSI DATABASE & LOGIK CRUD
// ==========================================
$db_file = '/var/www/html/web_users.db';
$db = new PDO("sqlite:" . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$msg = "";

// 1. CREATE USER
if (isset($_POST['add_user'])) {
    $tid = trim($_POST['telegram_id']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    try {
        $stmt = $db->prepare("INSERT INTO web_users (telegram_id, password) VALUES (?, ?)");
        $stmt->execute([$tid, $pass]);
        $msg = "<div class='alert success'>✅ User berhasil ditambahkan!</div>";
    } catch (Exception $e) {
        $msg = "<div class='alert error'>❌ Gagal: Username mungkin sudah ada.</div>";
    }
}

// 2. UPDATE USER
if (isset($_POST['update_user'])) {
    $id = $_POST['id'];
    $tid = trim($_POST['telegram_id']);
    $new_pass = $_POST['password'];

    if (!empty($new_pass)) {
        // Update username & password
        $pass = password_hash($new_pass, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE web_users SET telegram_id = ?, password = ? WHERE id = ?");
        $stmt->execute([$tid, $pass, $id]);
    } else {
        // Update username saja
        $stmt = $db->prepare("UPDATE web_users SET telegram_id = ? WHERE id = ?");
        $stmt->execute([$tid, $id]);
    }
    $msg = "<div class='alert success'>✅ Data User berhasil diupdate!</div>";
}

// 3. DELETE USER
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $db->prepare("DELETE FROM web_users WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin.php?msg=deleted");
    exit;
}
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $msg = "<div class='alert success'>✅ User berhasil dihapus!</div>";
}

// AMBIL SEMUA DATA (READ)
$users = $db->query("SELECT * FROM web_users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - J1BTNL Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        :root { 
            --primary-neon: #00e5ff; 
            --secondary-neon: #bd00ff;
            --bg-dark: #0a0a12;
            --glass-bg: rgba(20, 20, 30, 0.6);
            --glass-border: rgba(0, 229, 255, 0.2);
        }

        * { 
            box-sizing: border-box; 
            font-family: 'Poppins', sans-serif; 
            margin: 0;
            padding: 0;
        }

        body { 
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(circle at 15% 50%, rgba(189, 0, 255, 0.15), transparent 25%),
                radial-gradient(circle at 85% 30%, rgba(0, 229, 255, 0.15), transparent 25%);
            color: #fff; 
            padding: 30px 20px; 
            min-height: 100vh;
        }

        .container { 
            max-width: 1000px; 
            margin: auto; 
        }

        /* HEADER */
        .header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-bottom: 1px solid var(--glass-border); 
            padding-bottom: 20px; 
            margin-bottom: 30px; 
        }
        
        .header h2 { 
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary-neon), var(--secondary-neon));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        /* GLASSMORPHISM CARD */
        .card { 
            background: var(--glass-bg); 
            border: 1px solid var(--glass-border); 
            padding: 30px; 
            border-radius: 20px; 
            margin-bottom: 30px; 
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3), 0 0 20px rgba(189, 0, 255, 0.05); 
        }

        .card h3 { 
            color: #fff; 
            margin-bottom: 25px; 
            font-weight: 600; 
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card h3 i { color: var(--primary-neon); }

        /* TABLE */
        .table-container { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 0.95rem; }
        th { 
            color: var(--primary-neon); 
            font-weight: 600; 
            text-transform: uppercase; 
            font-size: 0.85rem; 
            letter-spacing: 1px; 
        }
        tr { transition: 0.3s; }
        tr:hover td { background: rgba(0, 229, 255, 0.05); }
        td strong { color: #fff; font-weight: 600; letter-spacing: 0.5px; }
        
        /* FORM & INPUTS */
        .form-inline { display: flex; gap: 15px; align-items: stretch; }
        .form-group-modal { margin-bottom: 15px; }
        .form-group-modal label { display: block; margin-bottom: 8px; color: #c8c8d0; font-size: 0.85rem; font-weight: 600; }
        
        input { 
            padding: 14px 15px; 
            border-radius: 10px; 
            border: 1px solid rgba(255,255,255,0.1); 
            background: rgba(0,0,0,0.4); 
            color: #fff; 
            width: 100%; 
            outline: none; 
            transition: 0.3s;
            font-size: 0.95rem;
        }
        input:focus { border-color: var(--primary-neon); box-shadow: 0 0 10px rgba(0, 229, 255, 0.2); }

        /* BUTTONS */
        .btn { 
            padding: 10px 20px; 
            border: none; 
            border-radius: 10px; 
            cursor: pointer; 
            font-weight: 600; 
            text-decoration: none; 
            display: inline-flex; 
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease; 
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        .btn:hover { transform: translateY(-2px); }

        .btn-add { background: linear-gradient(45deg, var(--secondary-neon), var(--primary-neon)); color: #fff; }
        .btn-add:hover { box-shadow: 0 5px 15px rgba(0, 229, 255, 0.4); }
        
        .btn-edit { background: rgba(0, 229, 255, 0.1); border: 1px solid var(--primary-neon); color: var(--primary-neon); padding: 8px 15px; }
        .btn-edit:hover { background: var(--primary-neon); color: #000; box-shadow: 0 5px 15px rgba(0, 229, 255, 0.4); }
        
        .btn-del { background: rgba(231, 76, 60, 0.1); border: 1px solid #e74c3c; color: #e74c3c; padding: 8px 15px; }
        .btn-del:hover { background: #e74c3c; color: #fff; box-shadow: 0 5px 15px rgba(231, 76, 60, 0.4); }
        
        .btn-logout { background: transparent; border: 1px solid #e74c3c; color: #e74c3c; }
        .btn-logout:hover { background: #e74c3c; color: #fff; box-shadow: 0 5px 15px rgba(231, 76, 60, 0.4); }

        .action-buttons { display: flex; gap: 10px; }

        /* ALERTS */
        .alert { padding: 15px; border-radius: 10px; margin-bottom: 30px; font-size: 0.9rem; display: flex; align-items: center; gap: 10px; }
        .success { background: rgba(46, 204, 113, 0.1); border: 1px solid #2ecc71; color: #2ecc71; }
        .error { background: rgba(231, 76, 60, 0.1); border: 1px solid #e74c3c; color: #e74c3c; }

        /* MODAL */
        .modal { 
            display: none; 
            position: fixed; 
            top: 0; left: 0; 
            width: 100%; height: 100%; 
            background: rgba(10, 10, 18, 0.8); 
            align-items: center; 
            justify-content: center; 
            backdrop-filter: blur(8px);
            z-index: 1000;
        }
        .modal-content { 
            background: var(--glass-bg); 
            padding: 40px; 
            border-radius: 20px; 
            border: 1px solid var(--primary-neon); 
            width: 90%; 
            max-width: 450px; 
            box-shadow: 0 10px 40px rgba(0,0,0,0.8), 0 0 30px rgba(0, 229, 255, 0.2); 
        }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            .form-inline { flex-direction: column; }
            .btn-add { width: 100%; }
            .header { flex-direction: column; gap: 15px; text-align: center; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-rocket"></i> J1BTNL Admin Panel</h2>
            <a href="?logout=true" class="btn btn-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>

        <!-- Notifikasi PHP -->
        <?= $msg ?>

        <div class="card">
            <h3><i class="fas fa-user-plus"></i> Tambah User Baru</h3>
            <form method="POST" class="form-inline">
                <input type="text" name="telegram_id" placeholder="Username / ID Telegram" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="add_user" class="btn btn-add" style="min-width: 160px;"><i class="fas fa-plus"></i> Tambah</button>
            </form>
        </div>

        <div class="card">
            <h3><i class="fas fa-users"></i> Daftar Web Users (<?= count($users) ?>)</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID DB</th>
                            <th>Username / ID Telegram</th>
                            <th>Hash Password</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($users) > 0): ?>
                            <?php foreach ($users as $u): ?>
                            <tr>
                                <td>#<?= $u['id'] ?></td>
                                <td><strong><?= htmlspecialchars($u['telegram_id']) ?></strong></td>
                                <td style="font-size: 0.8em; color: #8b8b99;">...<?= substr($u['password'], -15) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button onclick="editUser(<?= $u['id'] ?>, '<?= htmlspecialchars($u['telegram_id']) ?>')" class="btn btn-edit">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <a href="?delete=<?= $u['id'] ?>" onclick="return confirm('⚠️ Peringatan: Yakin ingin menghapus user ini secara permanen?');" class="btn btn-del">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" style="text-align: center; color: #8b8b99; padding: 30px;">Belum ada user yang terdaftar di database.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Edit User -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h3 style="color: #fff; margin-top: 0; margin-bottom: 25px; font-weight: 700;">
                <i class="fas fa-user-edit" style="color: var(--primary-neon); margin-right: 10px;"></i> Edit User
            </h3>
            <form method="POST">
                <input type="hidden" id="edit_id" name="id">
                
                <div class="form-group-modal">
                    <label>Username / ID Telegram:</label>
                    <input type="text" id="edit_username" name="telegram_id" required>
                </div>
                
                <div class="form-group-modal">
                    <label>Password Baru (Kosongkan jika tidak diubah):</label>
                    <input type="password" name="password" placeholder="***">
                </div>
                
                <div style="display: flex; gap: 15px; margin-top: 30px;">
                    <button type="submit" name="update_user" class="btn btn-add" style="flex: 1;"><i class="fas fa-save"></i> Simpan</button>
                    <button type="button" onclick="closeModal()" class="btn btn-del" style="flex: 1; border-color: #555; color: #ccc; background: rgba(255,255,255,0.05);"><i class="fas fa-times"></i> Batal</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function editUser(id, username) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_username').value = username;
            document.getElementById('editModal').style.display = 'flex';
        }
        
        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            let modal = document.getElementById('editModal');
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html>
